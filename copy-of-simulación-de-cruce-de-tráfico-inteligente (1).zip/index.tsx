
// React mounting is disabled for this standalone Vanilla JS project.
// The application logic is fully contained in index.html.
console.log("Standalone mode active.");
